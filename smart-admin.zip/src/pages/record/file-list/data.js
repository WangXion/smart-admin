export default [
    {
        project: '项目档案',
        desc: '档案编号档案编号档案编号',
        owner: 'Aresn',
        time: new Date('2016-07-28 14:00:00'),
        progress: 90,
        status: 'active'
    },
    {
        project: '合同档案',
        desc: '档案标题档案标题档案标题',
        owner: '中小鱼',
        time: new Date('2019-02-01 14:00:00'),
        progress: 100
    },
    {
        project: '设备档案',
        desc: '档案标题档案标题档案标题',
        owner: 'Echo',
        time: new Date('2019-03-01 14:00:00'),
        progress: 75
    },
    {
        project: '项目档案',
        desc: '借阅审批信息详情借阅审批信息详情借阅审批信息详情',
        owner: '唐不苦',
        time: new Date('2018-06-01 14:00:00'),
        progress: 75,
        status: 'active'
    },
    {
        project: '档案',
        desc: '档案档案档案',
        owner: '甜筒',
        time: new Date('2018-07-01 14:00:00'),
        progress: 75,
        status: 'wrong'
    }
];
