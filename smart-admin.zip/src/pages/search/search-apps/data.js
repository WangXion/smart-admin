export default [{
		title: 'iView',
		icon: 'https://dev-file.iviewui.com/RZ8FQmZfHkcffMlTBCJllBFjEhEsObVo/avatar',
		time: new Date('2016-07-28 14:00:00'),
		link: 'https://www.iviewui.com/',
		owner: 'Aresn'
	},
	{
		title: 'iView Pro',
		icon: 'https://dev-file.iviewui.com/WLXm7gp1EbLDtvVQgkeQeyq5OtDm00Jd/avatar',
		time: new Date('2019-02-01 14:00:00'),
		link: 'https://pro.iviewui.com/pro/',
		owner: '中小鱼'
	},
	{
		title: 'iView Admin Pro',
		icon: 'https://dev-file.iviewui.com/4Z0QR2L0J1XStxBh99jVJ8qLfsGsOgjU/avatar',
		time: new Date('2019-03-01 14:00:00'),
		link: 'https://pro.iviewui.com/admin-pro/',
		owner: 'Echo'
	},
	{
		title: 'iView Developer',
		icon: 'https://dev-file.iviewui.com/ttkIjNPlVDuv4lUTvRX8GIlM2QqSe0jg/avatar',
		time: new Date('2018-06-01 14:00:00'),
		link: 'https://dev.iviewui.com/',
		owner: '唐不苦'
	},
	{
		title: 'iView Run',
		icon: 'https://dev-file.iviewui.com/fAenQ8nvRjL7x0i0jEfuDBZHvJfHf3v6/avatar',
		time: new Date('2018-07-01 14:00:00'),
		link: 'https://run.iviewui.com/',
		owner: '甜筒'
	},
	{
		title: 'iView Editor',
		icon: 'https://dev-file.iviewui.com/LrCTN2j94lo9N7wEql7cBr1Ux4rHMvmZ/avatar',
		time: new Date('2018-07-05 14:00:00'),
		link: 'http://editor.iviewui.com/',
		owner: '冷月呆呆'
	},
	{
		title: 'iView Doc',
		icon: 'https://dev-file.iviewui.com/yeKvhT20lMU0f1T3Y743UlGEOLLnZSnp/avatar',
		time: new Date('2016-08-01 14:00:00'),
		link: 'https://www.iviewui.com/',
		owner: 'ludd'
	},
	{
		title: 'iView Cli',
		icon: 'https://dev-file.iviewui.com/CyrCNmTJfv7D6GFAg39bjT3eRkkRm5dI/avatar',
		time: new Date('2017-09-02 14:00:00'),
		link: 'https://iviewui.com/cli/',
		owner: '白灼菜心儿'
	}
];
