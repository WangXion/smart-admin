<template>
	<Card :bordered="false" dis-hover class="ivu-mt">
    <div style="width: 50%;margin-left:30px;">
        <Input search enter-button="搜索" placeholder="输入你要搜索的档案" />
    </div>
            <div style="margin-left:10px;margin:30px">
                    <div style="margin-top:20px">
                    <a href="">这是一段标题</a>
                    <p>这是一段描述这是一段描述这是一段描述这是一段描述这是一段描述这是一段描述这是一段描述这是一段描述这是一段描述这是一段描述</p>
                </div>
                        <div style="margin-top:20px">
                    <a href="">这是一段标题</a>
                    <p>这是一段描述这是一段描述这是一段描述这是一段描述这是一段描述这是一段描述这是一段描述这是一段描述这是一段描述这是一段描述</p>
                </div>
                        <div style="margin-top:20px">
                    <a href="">这是一段标题</a>
                    <p>这是一段描述这是一段描述这是一段描述这是一段描述这是一段描述这是一段描述这是一段描述这是一段描述这是一段描述这是一段描述</p>
                </div>
            </div>

    	</Card>
        
</template>

<script>
    export default {

    }
</script>