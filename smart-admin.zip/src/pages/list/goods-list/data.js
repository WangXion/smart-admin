export default [{
		cover: 'https://dev-file.iviewui.com/yxsk0RFxdR0X3S0N7QN33mvwLnkfHEJV/middle',
		title: 'Vue.js 实战',
		desc: 'Vue.js 作者尤雨溪作序',
		link: 'https://dev.iviewui.com/shop/1016967896695443456',
		price: 69,
		status: 1,
		is_recommend: 1
	},
	{
		cover: 'https://dev-file.iviewui.com/8WwJ7tWv9uZ8hepq8pDTjLQiHZy2MB9I/middle',
		title: '蒙马特城市安全防盗背包',
		desc: 'XDDESIGN 经典版',
		link: 'https://dev.iviewui.com/shop/1022361972508856320',
		price: 350,
		old_price: 450,
		status: 1,
		is_recommend: 0
	},
	{
		cover: 'https://dev-file.iviewui.com/PKCycgm3DWJOca5I2uAEqneuLFQAcKa7/middle',
		title: 'Sony 无线立体声耳机',
		desc: 'WH-H800',
		link: 'https://dev.iviewui.com/shop/1022369255729008640',
		price: 1450,
		status: 1,
		is_recommend: 0
	},
	{
		cover: 'https://dev-file.iviewui.com/KUa7CaC6m7vRtDCfY0SAXlp7dw9OvBrf/middle',
		title: '京东 E 卡（100元）',
		desc: '面值 100 元的京东E卡（电子卡）',
		link: 'https://dev.iviewui.com/shop/1018787663790084096',
		price: 100,
		status: 2,
		is_recommend: 0
	},
	{
		cover: 'https://dev-file.iviewui.com/UTPgv8fkOHXszM8Xxm33C2ABuTw7AlRE/middle',
		title: 'Cherry 机械键盘背光版',
		desc: 'Cherry MX BOARD 1.0',
		link: 'https://dev.iviewui.com/shop/1022357783686811648',
		price: 600,
		status: 1,
		is_recommend: 0
	},
	{
		cover: 'https://dev-file.iviewui.com/OYZqqiP1bbwN22Ai2HnwvSagxuSNchdD/middle',
		title: '妙控鼠标 2 - 银色',
		desc: 'Apple Mouse',
		link: 'https://dev.iviewui.com/shop/1022375656002031616',
		price: 582,
		status: 1,
		is_recommend: 0
	}
];
